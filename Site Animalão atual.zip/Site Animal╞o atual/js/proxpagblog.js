// Função para ir para a página anterior
function goToPreviousPage() {
    // Lógica para ir para a página anterior
}

// Função para ir para a próxima página
function goToNextPage() {
    // Lógica para ir para a próxima página
}

// Adicionando evento de clique ao botão de página anterior
document.getElementById('prev-page').addEventListener('click', goToPreviousPage);

// Adicionando evento de clique ao botão de próxima página
document.getElementById('next-page').addEventListener('click', goToNextPage);
