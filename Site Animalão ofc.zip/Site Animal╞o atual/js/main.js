import { renderizarCatalogo } from "./cartaoproduto.js";
import { inicializarCarrinho } from "./menuCarrinho.js";

renderizarCatalogo();
inicializarCarrinho();
