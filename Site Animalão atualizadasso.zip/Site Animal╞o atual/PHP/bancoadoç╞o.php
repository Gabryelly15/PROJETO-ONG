<?php
// Conexão
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "seu_banco_de_dados";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$nomeProduto = $_POST['nomeProduto'];
$valorProduto = $_POST['valorProduto'];

$sql = "INSERT INTO sua_tabela (nomeProduto, valorProduto) VALUES ('$nomeProduto', '$valorProduto')";

if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso";
} else {
    echo "Erro ao inserir dados: " . $conn->error;
}

$conn->close();
?>